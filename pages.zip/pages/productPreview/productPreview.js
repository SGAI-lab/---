Page({
  data: {
    name: '',
    price: '',
    categoryName: '',
    description: '',
    images: [],
    fields: []
  },

  onLoad() {
    // 获取从编辑/新增页面传递的数据
    const eventChannel = this.getOpenerEventChannel();
    eventChannel.on('sendProductData', (data) => {
      this.setData({
        name: data.name || '',
        price: data.price || '',
        categoryName: data.categoryName || '',
        description: data.description || '',
        images: data.images || [],
        fields: data.fields || []
      });
    });
  },

  // 返回编辑页面
  goBack() {
    wx.navigateBack(); // 返回到编辑或新增页面
  }
});