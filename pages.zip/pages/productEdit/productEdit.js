import cloudConfig from '../../config/cloudConfig'; // 引入 cloudConfig 文件

Page({
  data: {
    id: '',
    name: '',
    price: '',
    categories: [], // 动态加载分类
    category: '', // 存储选择的分类id
    categoryName: '', // 存储选择的分类名称
    description: '',
    images: [],
    fields: [],
    recommend: false, // 默认不推荐
    isSpecialOffer: false // 默认不是特价商品
  },

  onLoad(options) {
    const { id } = options;
    this.setData({ id });

    this.loadCategories(); // 加载分类信息
    this.loadProductDetails(id); // 加载商品详情
  },

  // 加载分类信息
  loadCategories() {
    const db = wx.cloud.database();
    db.collection('categories').get({
      success: res => {
        const categories = res.data.map(item => ({
          id: item._id,
          name: item.name
        }));
        this.setData({ categories });
      },
      fail: err => {
        console.error('加载分类失败：', err);
        wx.showToast({
          title: '加载分类失败',
          icon: 'none'
        });
      }
    });
  },

  // 加载商品详情
  loadProductDetails(id) {
    const db = wx.cloud.database();
    db.collection('products').doc(id).get({
      success: res => {
        const { name, price, category_id, description, images, fields, recommend, isSpecialOffer } = res.data;
        const categoryName = this.getCategoryName(category_id);
        this.setData({
          name,
          price,
          category: category_id,
          categoryName,
          description,
          images,
          fields: fields || [],
          recommend: recommend || false,
          isSpecialOffer: isSpecialOffer || false // 加载特价商品状态
        });
      },
      fail: err => {
        console.error('加载商品详情失败：', err);
        wx.showToast({
          title: '加载商品详情失败',
          icon: 'none'
        });
      }
    });
  },

  // 获取分类名称
  getCategoryName(categoryId) {
    const category = this.data.categories.find(item => item.id === categoryId);
    return category ? category.name : '';
  },

  // 商品名称输入
  onNameInput(e) {
    this.setData({ name: e.detail.value });
  },

  // 商品价格输入
  onPriceInput(e) {
    this.setData({ price: e.detail.value });
  },

  // 分类选择
  onCategoryChange(e) {
    const index = e.detail.value;
    const selectedCategory = this.data.categories[index];
    this.setData({
      category: selectedCategory.id,
      categoryName: selectedCategory.name
    });
  },

  // 商品描述输入
  onDescriptionInput(e) {
    this.setData({ description: e.detail.value });
  },

  // 图片上传
  chooseImage() {
    wx.chooseImage({
      count: 9, // 不限制上传数量
      success: res => {
        const files = res.tempFilePaths;
        const uploadTasks = files.map(filePath => {
          const timestamp = Date.now();
          const randomNum = Math.floor(Math.random() * 1000);
          const fileName = `${timestamp}-${randomNum}.png`; // 动态生成文件名
          const cloudPath = `products/${fileName}`; // 云存储路径

          return wx.cloud.uploadFile({
            cloudPath,
            filePath
          });
        });

        Promise.all(uploadTasks)
          .then(results => {
            const uploadedImages = results.map(res => res.fileID);
            this.setData({ images: this.data.images.concat(uploadedImages) });
            wx.showToast({ title: '图片上传成功', icon: 'success' });
          })
          .catch(err => {
            console.error('图片上传失败：', err);
            wx.showToast({
              title: '图片上传失败，请稍后重试',
              icon: 'none'
            });
          });
      },
      fail: err => {
        console.error('图片选择失败：', err);
        wx.showToast({
          title: '图片选择失败',
          icon: 'none'
        });
      }
    });
  },

  // 删除图片
  deleteImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = [...this.data.images];
    const fileToDelete = images.splice(index, 1)[0];

    wx.cloud.deleteFile({
      fileList: [fileToDelete],
      success: () => {
        this.setData({ images });
        wx.showToast({ title: '图片删除成功', icon: 'success' });
      },
      fail: err => {
        console.error('图片删除失败：', err);
        wx.showToast({
          title: '图片删除失败',
          icon: 'none'
        });
      }
    });
  },

  // 添加动态字段
  addField() {
    this.setData({ fields: [...this.data.fields, { key: '', value: '' }] });
  },

  // 删除动态字段
  removeField(e) {
    const index = e.currentTarget.dataset.index;
    const fields = [...this.data.fields];
    fields.splice(index, 1);
    this.setData({ fields });
  },

  // 动态字段键输入
  onFieldKeyInput(e) {
    const index = e.currentTarget.dataset.index;
    const fields = [...this.data.fields];
    fields[index].key = e.detail.value;
    this.setData({ fields });
  },

  // 动态字段值输入
  onFieldValueInput(e) {
    const index = e.currentTarget.dataset.index;
    const fields = [...this.data.fields];
    fields[index].value = e.detail.value;
    this.setData({ fields });
  },

  // 推荐商品选择
  onRecommendChange(e) {
    const value = e.detail.value === 'true';
    this.setData({ recommend: value });
  },

// 特价商品选择
onSpecialOfferChange(e) {
  // 确保正确更新开关状态
  this.setData({ 
    isSpecialOffer: e.detail.value // 修复为 e.detail.value，正确获取开关状态
  });
},

  // 商品预览
  previewProduct() {
    const { name, price, category, categoryName, description, images, fields } = this.data;

    if (!name || !price || !category) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    wx.navigateTo({
      url: '/pages/productPreview/productPreview',
      success: (res) => {
        res.eventChannel.emit('sendProductData', {
          name,
          price,
          categoryName,
          description,
          images,
          fields
        });
      }
    });
  },

  // 保存商品
  saveProduct() {
    const db = wx.cloud.database();
    const { id, name, price, category, description, images, fields, recommend, isSpecialOffer } = this.data;

    if (!name || !price || !category) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    db.collection('products')
      .doc(id)
      .update({
        data: {
          name,
          price,
          category_id: category,
          description,
          images,
          fields,
          recommend,
          isSpecialOffer // 保存特价商品状态
        }
      })
      .then(() => {
        wx.showToast({
          title: '商品修改成功',
          icon: 'success'
        });
        wx.navigateBack();
      })
      .catch(err => {
        console.error('商品修改失败：', err);
        wx.showToast({
          title: '修改失败',
          icon: 'none'
        });
      });
  }
});