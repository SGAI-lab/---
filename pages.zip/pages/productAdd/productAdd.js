import cloudConfig from '../../config/cloudConfig'; // 引入 cloudConfig 文件

Page({
  data: {
    name: '',
    price: '',
    categories: [], // 动态加载分类
    category: '', // 保存分类的 _id
    categoryName: '', // 保存分类的名称
    description: '',
    images: [],
    fields: [],
    status: '草稿', // 默认保存为草稿
    recommend: false, // 默认不推荐
    isSpecialOffer: false // 默认不是特价商品
  },

  onLoad() {
    this.loadCategories(); // 加载分类信息
  },

  // 加载分类信息
  loadCategories() {
    const db = wx.cloud.database();
    db.collection('categories').get({
      success: res => {
        const categories = res.data.map(category => ({
          id: category._id,
          name: category.name
        }));
        this.setData({ categories });
      },
      fail: err => {
        console.error(err);
        wx.showToast({
          title: '加载分类失败',
          icon: 'none'
        });
      }
    });
  },

  // 商品名称输入
  onNameInput(e) {
    this.setData({ name: e.detail.value });
  },

  // 商品价格输入
  onPriceInput(e) {
    this.setData({ price: e.detail.value });
  },

  // 分类选择
  onCategoryChange(e) {
    const index = e.detail.value;
    const selectedCategory = this.data.categories[index];
    this.setData({
      category: selectedCategory.id, // 保存分类的 _id
      categoryName: selectedCategory.name // 保存分类的名称
    });
  },

  // 商品描述输入
  onDescriptionInput(e) {
    this.setData({ description: e.detail.value });
  },

  // 图片上传
  chooseImage() {
    wx.chooseImage({
      count: 5,
      success: res => {
        const files = res.tempFilePaths; // 获取本地图片路径
        const uploadTasks = files.map(filePath => {
          const cloudPath = `products/${Date.now()}-${Math.floor(Math.random() * 1000)}.png`; // 动态云存储路径
          return wx.cloud.uploadFile({
            cloudPath,
            filePath
          });
        });

        // 上传所有图片到云存储
        Promise.all(uploadTasks)
          .then(results => {
            const uploadedImages = results.map(res => res.fileID); // 获取云存储路径
            this.setData({ images: this.data.images.concat(uploadedImages) });
            wx.showToast({ title: '图片上传成功', icon: 'success' });
          })
          .catch(err => {
            console.error('图片上传失败，详细信息：', err);
            wx.showToast({
              title: '图片上传失败，请稍后重试',
              icon: 'none'
            });
          });
      },
      fail: err => {
        console.error('图片选择失败：', err);
        wx.showToast({
          title: '图片选择失败',
          icon: 'none'
        });
      }
    });
  },

  // 删除图片
  deleteImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = [...this.data.images];
    images.splice(index, 1); // 删除指定索引的图片
    this.setData({ images });
  },

  // 添加动态字段
  addField() {
    this.setData({ fields: [...this.data.fields, { key: '', value: '' }] });
  },

  // 删除动态字段
  removeField(e) {
    const index = e.currentTarget.dataset.index;
    const fields = [...this.data.fields];
    fields.splice(index, 1);
    this.setData({ fields });
  },

  // 动态字段键值输入
  onFieldKeyInput(e) {
    const index = e.currentTarget.dataset.index;
    const fields = [...this.data.fields];
    fields[index].key = e.detail.value;
    this.setData({ fields });
  },

  // 动态字段值输入
  onFieldValueInput(e) {
    const index = e.currentTarget.dataset.index;
    const fields = [...this.data.fields];
    fields[index].value = e.detail.value;
    this.setData({ fields });
  },

  // 状态选择（草稿或已上架）
  onStatusChange(e) {
    this.setData({ status: e.detail.value });
  },

  // 推荐商品选择
  onRecommendChange(e) {
    const value = e.detail.value === 'true';
    this.setData({ recommend: value });
  },

  // 特价商品选择
  onSpecialOfferChange(e) {
    this.setData({ isSpecialOffer: e.detail.value }); // 更新特价商品状态
  },

  // 预览商品
  previewProduct() {
    const { name, price, category, categoryName, description, images, fields } = this.data;

    // 校验必填字段是否填写完整
    if (!name || !price || !category) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    // 跳转到商品预览页面，并通过 eventChannel 传递数据
    wx.navigateTo({
      url: '/pages/productPreview/productPreview',
      events: {}, // 注册事件监听（可选）
      success: function (res) {
        res.eventChannel.emit('sendProductData', {
          name,
          price,
          category,
          categoryName,
          description,
          images,
          fields
        });
      },
      fail: function (err) {
        console.error('跳转商品预览页面失败：', err);
        wx.showToast({
          title: '跳转失败',
          icon: 'none'
        });
      }
    });
  },

  // 保存商品
  saveProduct() {
    const db = wx.cloud.database();
    const { name, price, category, description, images, fields, status, recommend, isSpecialOffer } = this.data;

    if (!name || !price || !category) {
      wx.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }

    db.collection('products').add({
      data: {
        name,
        price,
        category_id: category, // 保存分类的 _id
        description,
        images, // 云存储路径
        fields,
        status,
        recommend, // 保存推荐字段
        isSpecialOffer // 保存特价商品状态
      },
      success: () => {
        wx.showToast({
          title: '商品保存成功',
          icon: 'success'
        });
        wx.navigateBack();
      },
      fail: err => {
        console.error('保存商品失败：', err);
        wx.showToast({
          title: '保存失败，请稍后重试',
          icon: 'none'
        });
      }
    });
  }
});