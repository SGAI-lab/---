Page({
  data: {
    carousel: [],
    categories: [],
    recommendations: []
  },

  onLoad() {
    this.loadCarousel();
    this.loadCategories();
    this.loadRecommendations();
  },

  // 加载轮播图数据
  loadCarousel() {
    const db = wx.cloud.database();
    db.collection('carousel').get({
      success: res => {
        console.log('Loaded carousel data:', res.data); // 调试信息
        // 确保 carousel 数据正确处理
        const carousel = res.data.map(item => ({
          image: item.imageUrl || '', // 确保有默认值
          productId: item.productId || '' // 确保 productId 不为空
        })).filter(item => item.image && item.productId); // 过滤无效数据
        this.setData({ carousel });
        console.log('Filtered carousel data:', carousel); // 调试信息
      },
      fail: err => {
        console.error('Failed to load carousel:', err);
        wx.showToast({ title: '加载轮播图失败', icon: 'none' });
      }
    });
  },

  // 加载商品分类数据
  loadCategories() {
    const db = wx.cloud.database();
    db.collection('categories').get({
      success: res => {
        const categories = res.data.map(item => ({
          id: item._id, // 确保绑定数据库的分类 _id
          name: item.name,
          icon: item.icon || '' // 如果有分类图标
        }));
        this.setData({ categories });
        console.log('Categories loaded:', categories); // 调试信息
      },
      fail: err => {
        console.error(err);
        wx.showToast({ title: '加载分类失败', icon: 'none' });
      }
    });
  },

  // 加载推荐商品数据
  loadRecommendations() {
    const db = wx.cloud.database();
    db.collection('products').where({
      recommend: true, // 与数据库字段 recommend 保持一致
      status: '已上架' // 确保只加载已上架的推荐商品
    }).get({
      success: res => {
        console.log('Loaded recommendations:', res.data); // 调试信息
        this.setData({ recommendations: res.data });
      },
      fail: err => {
        console.error('Failed to load recommendations:', err);
        wx.showToast({ title: '加载推荐商品失败', icon: 'none' });
      }
    });
  },

  // 跳转到商品详情页
  goToProductDetail(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) {
      console.error('No product ID found for navigation'); // 调试信息
      wx.showToast({ title: '商品 ID 不存在', icon: 'none' });
      return;
    }
    console.log('Navigating to Product Detail with ID:', id); // 调试信息
    wx.navigateTo({
      url: `/pages/productDetail/productDetail?id=${id}`
    });
  },

  // 跳转到分类页面
  goToCategory(e) {
    const id = e.currentTarget.dataset.id; // 从 data-id 获取分类 ID
    if (!id) {
      console.error('No category ID found for navigation'); // 调试信息
      wx.showToast({ title: '分类 ID 不存在', icon: 'none' });
      return;
    }
    console.log('Navigating to Category with ID:', id); // 调试信息
    wx.navigateTo({
      url: `/pages/category/category?id=${id}` // 将分类 ID 传递到分类页面
    });
  },

  // 跳转到特价商品页面
  goToSpecialOffer() {
    console.log('Navigating to Special Offer Page'); // 调试信息
    wx.navigateTo({
      url: `/pages/category/category?type=special` // 跳转并传递特价商品筛选参数
    });
  }
});