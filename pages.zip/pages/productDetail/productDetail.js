Page({
  data: {
    images: [], // 商品图片
    name: '', // 商品名称
    price: '', // 商品价格
    productId: '', // 商品ID
    fields: [] // 其他字段
  },

  onLoad(options) {
    const { id } = options;
    this.setData({ productId: id }); // 保存商品ID
    this.loadProductDetails(id);
  },

  // 加载商品详情
  loadProductDetails(id) {
    const db = wx.cloud.database();
    db.collection('products')
      .doc(id)
      .get({
        success: res => {
          const { images, name, price, fields, description } = res.data;
          this.setData({
            images,
            name,
            price,
            description: description || '', // 确保字段存在
            fields
          });
        },
        fail: err => {
          console.error('加载商品详情失败:', err);
          wx.showToast({
            title: '加载失败',
            icon: 'none'
          });
        }
      });
  },

  // 加入购物车
  addToCart() {
    const userInfo = wx.getStorageSync('userInfo');
    if (!userInfo || !userInfo.openid) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }

    const db = wx.cloud.database();
    const { openid } = userInfo;
    const { productId, name, price } = this.data;

    // 查询购物车中是否已存在该商品
    db.collection('cart')
      .where({
        openid,
        productId
      })
      .get()
      .then(res => {
        if (res.data.length > 0) {
          // 如果已存在，增加数量
          const cartItemId = res.data[0]._id;
          db.collection('cart')
            .doc(cartItemId)
            .update({
              data: {
                quantity: db.command.inc(1) // 数量+1
              }
            })
            .then(() => {
              this.setCartUpdateFlag(); // 通知购物车页面刷新
              wx.showToast({
                title: '购物车数量已更新',
                icon: 'success'
              });
            })
            .catch(err => {
              console.error('更新购物车失败:', err);
              wx.showToast({
                title: '更新失败',
                icon: 'none'
              });
            });
        } else {
          // 如果不存在，新增记录
          db.collection('cart')
            .add({
              data: {
                openid,
                productId,
                name,
                price,
                quantity: 1, // 初始数量为1
                addedAt: new Date() // 添加时间
              }
            })
            .then(() => {
              this.setCartUpdateFlag(); // 通知购物车页面刷新
              wx.showToast({
                title: '已加入购物车',
                icon: 'success'
              });
            })
            .catch(err => {
              console.error('加入购物车失败:', err);
              wx.showToast({
                title: '加入失败',
                icon: 'none'
              });
            });
        }
      })
      .catch(err => {
        console.error('查询购物车失败:', err);
        wx.showToast({
          title: '加入失败',
          icon: 'none'
        });
      });
  },

  // 通知购物车页面刷新
  setCartUpdateFlag() {
    wx.setStorageSync('cartUpdated', true); // 设置全局更新标志
  },

  // 点击轮播图放大查看
  previewImage(e) {
    const current = e.currentTarget.dataset.src; // 当前点击的图片链接
    wx.previewImage({
      current, // 当前显示图片的链接
      urls: this.data.images // 所有图片链接
    });
  },

  // 分享功能 - 处理分享逻辑
  onShare() {
    wx.showShareMenu({
      withShareTicket: true, // 允许分享时带票据
      menus: ['shareAppMessage', 'shareTimeline'] // 支持分享到好友和朋友圈
    });
    wx.showToast({
      title: '点击右上角分享！',
      icon: 'none'
    });
  },

  // 自定义分享设置
  onShareAppMessage() {
    const { name, price, productId, images } = this.data;
    return {
      title: `看看这个商品：${name}，仅需￥${price}`,
      path: `/pages/productDetail/productDetail?id=${productId}`,
      imageUrl: images[0] || '' // 分享时显示的图片
    };
  }
});