Page({
  data: {
    cartItems: [], // 购物车商品列表，包含详细商品信息
    totalPrice: 0, // 总价
  },

  onLoad() {
    this.loadCartData();
  },

  // 页面显示时刷新购物车数据
  onShow() {
    const cartUpdated = wx.getStorageSync('cartUpdated');
    if (cartUpdated) {
      this.loadCartData();
      wx.setStorageSync('cartUpdated', false); // 重置标志
    }
  },

  // 加载购物车数据
  loadCartData() {
    const openid = wx.getStorageSync('userInfo').openid;

    if (!openid) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    const db = wx.cloud.database();

    // 先获取购物车数据
    db.collection('cart')
      .where({ openid })
      .get()
      .then(res => {
        const cartItems = res.data;

        // 获取所有商品的 productId
        const productIds = cartItems.map(item => item.productId);

        if (productIds.length === 0) {
          this.setData({ cartItems: [], totalPrice: 0 });
          return;
        }

        // 根据 productId 获取商品详情
        db.collection('products')
          .where({ _id: db.command.in(productIds) })
          .get()
          .then(productRes => {
            const products = productRes.data;

            // 合并购物车数据和商品详情数据
            const mergedCartItems = cartItems.map(cartItem => {
              const product = products.find(p => p._id === cartItem.productId);
              return {
                ...cartItem,
                productName: product ? product.name : '未知商品',
                productPrice: product ? product.price : 0,
                productImage: product ? product.images[0] : '',
              };
            });

            // 计算总价
            const totalPrice = mergedCartItems.reduce(
              (total, item) => total + item.quantity * item.productPrice,
              0
            );

            this.setData({ cartItems: mergedCartItems, totalPrice });
          })
          .catch(err => {
            console.error('加载商品详情失败：', err);
            wx.showToast({ title: '加载商品失败', icon: 'none' });
          });
      })
      .catch(err => {
        console.error('加载购物车失败：', err);
        wx.showToast({ title: '加载失败', icon: 'none' });
      });
  },

  // 增加商品数量
  incrementQuantity(e) {
    const id = e.currentTarget.dataset.id;
    const db = wx.cloud.database();

    db.collection('cart')
      .doc(id)
      .update({
        data: { quantity: db.command.inc(1) },
      })
      .then(() => {
        this.loadCartData();
      });
  },

  // 减少商品数量
  decrementQuantity(e) {
    const id = e.currentTarget.dataset.id;
    const db = wx.cloud.database();

    const currentItem = this.data.cartItems.find(item => item._id === id);
    if (currentItem.quantity <= 1) {
      this.removeCartItem(e); // 如果数量为1，则删除
      return;
    }

    db.collection('cart')
      .doc(id)
      .update({
        data: { quantity: db.command.inc(-1) },
      })
      .then(() => {
        this.loadCartData();
      });
  },

  // 删除商品
  removeCartItem(e) {
    const id = e.currentTarget.dataset.id;
    const db = wx.cloud.database();

    db.collection('cart')
      .doc(id)
      .remove()
      .then(() => {
        this.loadCartData();
      });
  },

  // 点击商品图片跳转到商品详情页
  navigateToProductDetail(e) {
    const productId = e.currentTarget.dataset.productId; // 从商品数据中获取 productId
    wx.navigateTo({
      url: `/pages/productDetail/productDetail?id=${productId}`, // 跳转到详情页
    });
  },

  // 结算
  checkout() {
    wx.showToast({ title: '结算功能开发中', icon: 'none' });
  },
});