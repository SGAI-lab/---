import cloudConfig from '../../config/cloudConfig'; // 引入 cloudConfig 文件

Page({
  data: {
    filterOptions: [
      ['全部', '特价'], // 第一列：商品类型
      [] // 第二列：商品分类（动态加载）
    ],
    selectedFilters: [0, 0], // 当前选中的商品类型和分类索引
    categories: [], // 分类列表，保存ID和名称
    products: [], // 商品列表
    searchKeyword: '', // 搜索关键字
    loading: false, // 加载状态
    hasMore: true, // 是否还有更多数据
    page: 0, // 当前页码
    pageSize: 20, // 每页加载的商品数量
    searchIcon: `cloud://${cloudConfig.env}.696d-${cloudConfig.env}-1331469944/icon/list-magnifying-glass.svg`, // 搜索图标路径
  },

  onLoad(options) {
    const { id: categoryId = '', type = '' } = options; // 获取分类 ID 和筛选类型
    this.loadCategories(() => {
      if (type === 'special') {
        // 处理特价商品的筛选
        this.setData({
          selectedFilters: [1, 0] // 设置筛选为特价商品 - 全部分类
        });
        this.resetProducts({ isSpecialOffer: true, status: '已上架' }); // 加载特价商品
      } else if (categoryId) {
        // 如果传递了分类 ID
        const categoryIndex = this.data.categories.findIndex(cat => cat.id === categoryId);
        if (categoryIndex !== -1) {
          this.setData({
            selectedFilters: [0, categoryIndex + 1], // 设置筛选器默认选中分类
          });
          this.resetProducts({ category_id: categoryId, status: '已上架' }); // 加载该分类的商品
        } else {
          this.resetProducts(); // 如果分类 ID 不存在，则加载全部商品
        }
      } else {
        // 如果没有传递分类 ID，则加载全部商品
        this.resetProducts();
      }
    });
    this.loadSearchIcon(); // 加载搜索图标
  },

  // 加载分类信息
  loadCategories(callback) {
    const db = wx.cloud.database();
    db.collection('categories').get({
      success: res => {
        const categories = res.data.map(item => ({
          id: item._id, // 分类ID
          name: item.name, // 分类名称
        }));
        const filterOptions = [...this.data.filterOptions];
        filterOptions[1] = ['全部分类', ...categories.map(item => item.name)]; // 设置分类列数据
        this.setData({ filterOptions, categories }, () => {
          if (callback) callback(); // 分类加载完成后执行回调
        });
      },
      fail: err => {
        wx.showToast({ title: '加载分类失败', icon: 'none' });
      },
    });
  },

  // 重置商品列表
  resetProducts(filter = {}) {
    this.setData({
      products: [],
      page: 0,
      hasMore: true,
    }, () => {
      this.loadProducts(filter); // 初次加载商品
    });
  },

  // 加载商品数据（分页）
  loadProducts(filter = {}) {
    if (this.data.loading || !this.data.hasMore) return; // 防止重复加载或无更多数据

    const db = wx.cloud.database();
    const { page, pageSize, products } = this.data;

    this.setData({ loading: true });

    db.collection('products')
      .where(filter)
      .skip(page * pageSize) // 跳过前面的数据
      .limit(pageSize) // 加载一页数据
      .get({
        success: res => {
          const newProducts = res.data;
          this.setData({
            products: products.concat(newProducts), // 追加新数据
            hasMore: newProducts.length === pageSize, // 判断是否还有更多数据
            page: page + 1, // 更新页码
            loading: false, // 结束加载状态
          });
        },
        fail: err => {
          wx.showToast({ title: '加载商品失败', icon: 'none' });
          this.setData({ loading: false });
        },
      });
  },

  // 搜索输入
  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value });
  },

  // 搜索商品
  searchProducts() {
    const { filterOptions, selectedFilters, searchKeyword } = this.data;
    const selectedType = filterOptions[0][selectedFilters[0]];
    const selectedCategoryIndex = selectedFilters[1];

    const filter = { status: '已上架' };

    // 根据商品类型筛选
    if (selectedType === '特价') {
      filter.isSpecialOffer = true;
    }

    // 根据分类筛选
    if (selectedCategoryIndex > 0) { // 非“全部分类”
      const selectedCategory = this.data.categories[selectedCategoryIndex - 1];
      filter.category_id = selectedCategory.id; // 使用分类ID进行筛选
    }

    // 根据搜索关键字筛选
    if (searchKeyword) {
      filter.name = wx.cloud.database().RegExp({
        regexp: searchKeyword,
        options: 'i', // 不区分大小写
      });
    }

    this.resetProducts(filter); // 重新加载筛选后的商品
  },

  // 筛选器事件
  onFilterChange(e) {
    const selectedFilters = e.detail.value; // 获取多列选择的索引
    this.setData({ selectedFilters });

    const filter = {};
    const { filterOptions, categories } = this.data;
    const selectedType = filterOptions[0][selectedFilters[0]];
    const selectedCategoryIndex = selectedFilters[1];

    // 根据商品类型筛选
    if (selectedType === '特价') {
      filter.isSpecialOffer = true;
    }

    // 根据分类筛选
    if (selectedCategoryIndex > 0) { // 非“全部分类”
      const selectedCategory = categories[selectedCategoryIndex - 1];
      filter.category_id = selectedCategory.id; // 使用分类ID进行筛选
    }

    this.resetProducts(filter); // 重新加载筛选后的商品
  },

  // 加载搜索图标
  loadSearchIcon() {
    wx.cloud.getTempFileURL({
      fileList: [this.data.searchIcon],
      success: res => {
        if (res.fileList[0].status === 0) {
          this.setData({ searchIcon: res.fileList[0].tempFileURL });
        }
      },
      fail: err => {
        console.error('加载搜索图标失败:', err);
      },
    });
  },

  // 跳转到商品详情页面
  goToProductDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/productDetail/productDetail?id=${id}`,
    });
  },

  // 监听用户滚动到底部事件
  onReachBottom() {
    if (this.data.hasMore) {
      this.loadProducts(); // 加载下一页数据
    } else {
      wx.showToast({ title: '没有更多商品了', icon: 'none' });
    }
  },
});