Page({
  data: {
    filteredProducts: [], // 搜索过滤后的商品列表
    selectedProductId: '', // 当前选择的商品 ID
    selectedProductName: '', // 当前选择的商品名称
    carouselImages: [], // 轮播图数据，包含商品名称
    searchQuery: '', // 搜索框输入内容
  },

  onLoad() {
    this.loadCarouselImages(); // 加载轮播图
  },

  // 搜索框输入事件，触发搜索
  onSearchInput(e) {
    const searchQuery = e.detail.value;
    this.setData({
      searchQuery: searchQuery, // 更新搜索框的内容
    });
    this.searchProducts(searchQuery); // 触发搜索操作
  },

  // 从数据库中根据搜索查询实时获取商品
  searchProducts(query) {
    const db = wx.cloud.database();

    // 如果没有输入搜索内容，直接返回
    if (!query) {
      this.setData({
        filteredProducts: [] // 清空过滤结果
      });
      return;
    }

    // 从数据库中进行模糊查询，筛选已上架的商品
    db.collection('products')
      .where({
        status: '已上架',
        name: db.RegExp({
          regexp: query,
          options: 'i', // 忽略大小写
        }),
      })
      .get({
        success: res => {
          // 更新搜索后的商品列表
          this.setData({
            filteredProducts: res.data,
          });
        },
        fail: err => {
          wx.showToast({ title: '搜索失败', icon: 'none' });
          console.error(err);
        }
      });
  },

  // 选择商品
  onProductChange(e) {
    const index = e.detail.value;
    this.setData({
      selectedProductId: this.data.filteredProducts[index]._id,
      selectedProductName: this.data.filteredProducts[index].name
    });
  },

  // 上传图片
  chooseImage() {
    const { selectedProductId } = this.data;
    if (!selectedProductId) {
      wx.showToast({ title: '请选择商品', icon: 'none' });
      return;
    }

    wx.chooseImage({
      count: 1,
      success: res => {
        const filePath = res.tempFilePaths[0];
        const cloudPath = `carousel/${Date.now()}-${Math.random()}.jpg`;

        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: uploadRes => {
            this.saveCarouselImage(uploadRes.fileID);
          },
          fail: err => {
            wx.showToast({ title: '图片上传失败', icon: 'none' });
            console.error(err);
          }
        });
      }
    });
  },

  // 保存轮播图
  saveCarouselImage(imageUrl) {
    const { selectedProductId } = this.data;
    const db = wx.cloud.database();
    db.collection('carousel').add({
      data: {
        imageUrl,
        productId: selectedProductId
      },
      success: () => {
        wx.showToast({ title: '轮播图已保存', icon: 'success' });
        this.loadCarouselImages();
      },
      fail: err => {
        wx.showToast({ title: '保存失败', icon: 'none' });
        console.error(err);
      }
    });
  },

  // 删除轮播图
  deleteCarouselImage(e) {
    const id = e.currentTarget.dataset.id;
    const db = wx.cloud.database();
    db.collection('carousel').doc(id).remove({
      success: () => {
        wx.showToast({ title: '已删除', icon: 'success' });
        this.loadCarouselImages();
      },
      fail: err => {
        wx.showToast({ title: '删除失败', icon: 'none' });
        console.error(err);
      }
    });
  },

  // 加载轮播图并获取对应商品名称
  loadCarouselImages() {
    const db = wx.cloud.database();
    db.collection('carousel').get({
      success: res => {
        const carouselData = res.data;
        const productIds = carouselData.map(item => item.productId);

        // 查询所有相关商品名称
        db.collection('products').where({
          _id: db.command.in(productIds)
        }).get({
          success: productRes => {
            const productMap = {};
            productRes.data.forEach(product => {
              productMap[product._id] = product.name;
            });

            // 合并商品名称到轮播图数据
            const updatedCarouselData = carouselData.map(item => ({
              ...item,
              productName: productMap[item.productId] || '未知商品'
            }));

            this.setData({ carouselImages: updatedCarouselData });
          },
          fail: err => {
            wx.showToast({ title: '加载商品名称失败', icon: 'none' });
            console.error(err);
          }
        });
      },
      fail: err => {
        wx.showToast({ title: '加载轮播图失败', icon: 'none' });
        console.error(err);
      }
    });
  }
});