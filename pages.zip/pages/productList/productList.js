import cloudConfig from '../../config/cloudConfig'; // 引入 cloudConfig 文件

Page({
  data: {
    filterOptions: [
      ['全部', '特价'], // 第一列：商品类型
      [] // 第二列：商品分类（动态加载）
    ],
    selectedFilters: [0, 0], // 当前选中的商品类型和分类索引
    categories: [], // 分类数据，保存ID和名称
    products: [], // 商品数据
    searchKeyword: '', // 搜索关键字
    loading: false, // 加载状态
    hasMore: true, // 是否还有更多数据
    page: 0, // 当前页码
    pageSize: 20, // 每页加载的商品数量
    searchIcon: `cloud://${cloudConfig.env}.696d-${cloudConfig.env}-1331469944/icon/list-magnifying-glass.svg`, // 动态搜索图标路径
  },

  onLoad() {
    this.loadCategories(() => {
      this.resetProducts(); // 默认加载全部商品
    });
    this.loadSearchIcon(); // 尝试加载云端搜索图标
  },

  // 加载分类信息
  loadCategories(callback) {
    const db = wx.cloud.database();
    db.collection('categories').get({
      success: res => {
        const categories = res.data.map(item => ({
          id: item._id, // 分类ID
          name: item.name, // 分类名称
        }));
        const filterOptions = [...this.data.filterOptions];
        filterOptions[1] = ['全部分类', ...categories.map(item => item.name)]; // 设置分类列数据
        this.setData({ filterOptions, categories }, () => {
          if (callback) callback(); // 分类加载完成后执行回调
        });
      },
      fail: err => {
        console.error('加载分类失败:', err);
        wx.showToast({ title: '加载分类失败', icon: 'none' });
      },
    });
  },

  // 重置商品列表
  resetProducts(filter = {}) {
    this.setData({
      products: [],
      page: 0,
      hasMore: true,
    }, () => {
      this.loadProducts(filter); // 初次加载商品
    });
  },

  // 加载商品列表（分页）
  loadProducts(filter = {}) {
    if (this.data.loading || !this.data.hasMore) return; // 防止重复加载或无更多数据

    const db = wx.cloud.database();
    const { page, pageSize, products, filterOptions, selectedFilters, categories, searchKeyword } = this.data;

    const selectedType = filterOptions[0][selectedFilters[0]]; // 第一列：商品类型
    const selectedCategoryIndex = selectedFilters[1]; // 第二列：分类索引

    // 构建筛选条件
    const filters = { ...filter, status: '已上架' }; // 确保只加载已上架商品

    if (selectedType === '特价') {
      filters.isSpecialOffer = true; // 筛选特价商品
    }

    if (selectedCategoryIndex > 0) { // 非“全部分类”
      const selectedCategory = categories[selectedCategoryIndex - 1]; // 索引修正
      filters.category_id = selectedCategory.id; // 使用分类ID进行筛选
    }

    if (searchKeyword) {
      filters.name = db.RegExp({
        regexp: searchKeyword,
        options: 'i', // 不区分大小写
      });
    }

    this.setData({ loading: true });

    db.collection('products')
      .where(filters)
      .skip(page * pageSize) // 跳过前面的数据
      .limit(pageSize) // 加载一页数据
      .get({
        success: res => {
          const newProducts = res.data;
          this.setData({
            products: products.concat(newProducts), // 追加新数据
            hasMore: newProducts.length === pageSize, // 判断是否还有更多数据
            page: page + 1, // 更新页码
            loading: false, // 结束加载状态
          });
        },
        fail: err => {
          console.error('加载商品失败:', err);
          this.setData({ loading: false });
          wx.showToast({ title: '加载商品失败', icon: 'none' });
        },
      });
  },

  // 搜索输入
  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value });
  },

  // 搜索商品
  searchProducts() {
    this.resetProducts(); // 重置商品列表并重新加载
  },

  // 筛选器事件
  onFilterChange(e) {
    const selectedFilters = e.detail.value; // 获取多列选择的索引
    this.setData({ selectedFilters }, () => {
      this.resetProducts(); // 更新筛选条件并重新加载商品
    });
  },

  // 加载搜索图标
  loadSearchIcon() {
    wx.cloud.getTempFileURL({
      fileList: [this.data.searchIcon],
      success: res => {
        if (res.fileList[0].status === 0) {
          this.setData({ searchIcon: res.fileList[0].tempFileURL });
        } else {
          console.warn('云端搜索图标加载失败，使用默认本地图标');
        }
      },
      fail: err => {
        console.error('加载搜索图标失败:', err);
      },
    });
  },

  // 跳转到商品详情页
  goToProductDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/productDetail/productDetail?id=${id}`,
    });
  },

  // 监听用户滚动到底部事件
  onReachBottom() {
    if (this.data.hasMore) {
      this.loadProducts(); // 加载下一页数据
    } else {
      wx.showToast({ title: '没有更多商品了', icon: 'none' });
    }
  },
});