Page({
  data: {
    categories: [], // 动态加载分类，包含 id 和 name
    selectedCategory: '全部分类', // 当前筛选的分类名称
    selectedCategoryId: '', // 当前筛选的分类 ID
    searchIcon: 'cloud://images-4ghb9rxyf48e9544.696d-images-4ghb9rxyf48e9544-1331469944/icon/list-magnifying-glass.svg',

    // 已上架商品分页状态
    productsOnShelf: [], // 当前页的商品数据
    shelfPage: 1, // 当前页码
    shelfPageSize: 10, // 每页显示的商品数量
    shelfTotalPages: 1, // 总页数
    shelfPageOptions: [], // 页码数组，用于分页跳转选择
    shelfSearchKeyword: '', // 搜索关键词

    // 草稿商品分页状态
    drafts: [], // 当前页的草稿数据
    draftPage: 1, // 当前页码
    draftPageSize: 10, // 每页显示的商品数量
    draftTotalPages: 1, // 总页数
    draftPageOptions: [], // 页码数组，用于分页跳转选择
    draftSearchKeyword: '', // 搜索关键词

    qrCodeBase64: '' // 用于存储生成的二维码的 Base64 数据
  },

  onLoad() {
    this.loadCategories(); // 加载分类信息
    this.loadShelfProducts(); // 加载已上架商品
    this.loadDraftProducts(); // 加载草稿商品
  },

  // 更新上架商品的搜索关键词
  updateShelfSearchKeyword(e) {
    this.setData({
      shelfSearchKeyword: e.detail.value // 更新关键词到 data 中
    });
    console.log("更新后的关键词:", this.data.shelfSearchKeyword); // 调试日志
  },

// 更新草稿商品的搜索关键词
updateDraftSearchKeyword(e) {
  this.setData({ draftSearchKeyword: e.detail.value });
  console.log("更新后的关键词:", this.data.draftSearchKeyword); // 调试日志
},

  // 更新页码选项
  updateShelfPageOptions() {
    const totalPages = this.data.shelfTotalPages || 1;
    this.setData({
      shelfPageOptions: Array.from({ length: totalPages }, (_, i) => i + 1)
    });
  },

  updateDraftPageOptions() {
    const totalPages = this.data.draftTotalPages || 1;
    this.setData({
      draftPageOptions: Array.from({ length: totalPages }, (_, i) => i + 1)
    });
  },

  // 加载分类信息
  loadCategories() {
    const db = wx.cloud.database();
    db.collection('categories').get({
      success: res => {
        const categories = [{ id: '', name: '全部分类' }, ...res.data.map(category => ({
          id: category._id,
          name: category.name
        }))]; // 新增"全部分类"
        this.setData({ categories });
      },
      fail: err => {
        console.error(err);
        wx.showToast({
          title: '加载分类失败',
          icon: 'none'
        });
      }
    });
  },

// 加载已上架商品
loadShelfProducts() {
  const db = wx.cloud.database();
  const { shelfPage, shelfPageSize, selectedCategoryId, shelfSearchKeyword } = this.data;

  // 构建过滤条件
  const filter = { status: '已上架' };
  if (selectedCategoryId) filter.category_id = selectedCategoryId;
  if (shelfSearchKeyword) {
    filter.name = db.RegExp({
      regexp: shelfSearchKeyword,
      options: 'i' // 忽略大小写
    });
  }

  console.log("加载已上架商品条件:", filter);

  // 查询商品总数
  db.collection('products')
    .where(filter)
    .count({
      success: countRes => {
        const total = countRes.total;
        const totalPages = Math.ceil(total / shelfPageSize);
        console.log("已上架商品总数:", total, "总页数:", totalPages);

        // 更新分页选项
        this.setData({ shelfTotalPages: totalPages });
        this.updateShelfPageOptions();

        // 查询当前页商品
        db.collection('products')
          .where(filter)
          .skip((shelfPage - 1) * shelfPageSize)
          .limit(shelfPageSize)
          .get({
            success: res => {
              console.log("加载的已上架商品:", res.data);
              this.setData({
                productsOnShelf: res.data
              });
            },
            fail: err => {
              console.error("加载已上架商品失败:", err);
              wx.showToast({
                title: '加载失败',
                icon: 'none'
              });
            }
          });
      },
      fail: err => {
        console.error("获取已上架商品总数失败:", err);
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      }
    });
},

// 加载草稿商品
loadDraftProducts() {
  const db = wx.cloud.database();
  const { draftPage, draftPageSize, selectedCategoryId, draftSearchKeyword } = this.data;

  // 构建过滤条件
  const filter = { status: '草稿' };
  if (selectedCategoryId) filter.category_id = selectedCategoryId;
  if (draftSearchKeyword) {
    filter.name = db.RegExp({
      regexp: draftSearchKeyword,
      options: 'i' // 忽略大小写
    });
  }

  console.log("加载草稿商品条件:", filter);

  // 查询商品总数
  db.collection('products')
    .where(filter)
    .count({
      success: countRes => {
        const total = countRes.total;
        const totalPages = Math.ceil(total / draftPageSize);
        console.log("草稿商品总数:", total, "总页数:", totalPages);

        // 更新分页选项
        this.setData({ draftTotalPages: totalPages });
        this.updateDraftPageOptions();

        // 查询当前页商品
        db.collection('products')
          .where(filter)
          .skip((draftPage - 1) * draftPageSize)
          .limit(draftPageSize)
          .get({
            success: res => {
              console.log("加载的草稿商品:", res.data);
              this.setData({
                drafts: res.data
              });
            },
            fail: err => {
              console.error("加载草稿商品失败:", err);
              wx.showToast({
                title: '加载失败',
                icon: 'none'
              });
            }
          });
      },
      fail: err => {
        console.error("获取草稿商品总数失败:", err);
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      }
    });
},
  // 分类筛选
  onCategoryChange(e) {
    const index = e.detail.value;
    const selectedCategory = this.data.categories[index];
    this.setData({
      selectedCategory: selectedCategory.name,
      selectedCategoryId: selectedCategory.id,
      shelfPage: 1,
      draftPage: 1
    });
    this.loadShelfProducts();
    this.loadDraftProducts();
  },

// 搜索已上架商品
searchShelfProducts() {
  const keyword = this.data.shelfSearchKeyword.trim(); // 从 data 中获取关键词，去掉多余空格
  const { selectedCategoryId } = this.data; // 当前分类筛选条件

  if (!keyword) {
    wx.showToast({
      title: '请输入搜索关键词',
      icon: 'none'
    });
    return;
  }

  this.setData({
    shelfPage: 1 // 搜索从第一页开始
  });

  console.log("分类筛选:", selectedCategoryId, "搜索关键字:", keyword);

  // 加载商品数据，结合分类筛选和搜索关键字
  this.loadShelfProducts();
},

// 搜索草稿商品
searchDraftProducts() {
  const keyword = this.data.draftSearchKeyword.trim(); // 从 data 中获取关键词，去掉多余空格
  const { selectedCategoryId } = this.data; // 当前分类筛选条件

  if (!keyword) {
    wx.showToast({
      title: '请输入搜索关键词',
      icon: 'none'
    });
    return;
  }

  this.setData({
    draftPage: 1 // 搜索从第一页开始
  });

  console.log("分类筛选:", selectedCategoryId, "搜索关键字:", keyword);

  // 加载商品数据，结合分类筛选和搜索关键字
  this.loadDraftProducts();
},

  // 分页切换
  goToPreviousShelfPage() {
    if (this.data.shelfPage > 1) {
      this.setData({ shelfPage: this.data.shelfPage - 1 });
      this.loadShelfProducts();
    }
  },

  goToNextShelfPage() {
    if (this.data.shelfPage < this.data.shelfTotalPages) {
      this.setData({ shelfPage: this.data.shelfPage + 1 });
      this.loadShelfProducts();
    }
  },

  goToPreviousDraftPage() {
    if (this.data.draftPage > 1) {
      this.setData({ draftPage: this.data.draftPage - 1 });
      this.loadDraftProducts();
    }
  },

  goToNextDraftPage() {
    if (this.data.draftPage < this.data.draftTotalPages) {
      this.setData({ draftPage: this.data.draftPage + 1 });
      this.loadDraftProducts();
    }
  },

  // 页码跳转
  jumpToShelfPage(e) {
    const selectedPage = parseInt(e.detail.value) + 1; // picker 返回的索引 +1 对应实际页码
    console.log("选择的页码:", selectedPage);

    if (selectedPage >= 1 && selectedPage <= this.data.shelfTotalPages) {
      this.setData({ shelfPage: selectedPage });
      console.log("更新后的 shelfPage:", this.data.shelfPage);
      this.loadShelfProducts();
    } else {
      console.error("选择的页码超出范围:", selectedPage);
    }
  },

  jumpToDraftPage(e) {
    const selectedPage = parseInt(e.detail.value) + 1; // picker 返回的索引 +1 对应实际页码
    console.log("选择的页码:", selectedPage);

    if (selectedPage >= 1 && selectedPage <= this.data.draftTotalPages) {
      this.setData({ draftPage: selectedPage });
      console.log("更新后的 draftPage:", this.data.draftPage);
      this.loadDraftProducts();
    } else {
      console.error("选择的页码超出范围:", selectedPage);
    }
  },

  // 删除商品
  deleteProduct(e) {
    const id = e.currentTarget.dataset.id;
    const db = wx.cloud.database();

    wx.showModal({
      title: '确认删除',
      content: '确定要删除该商品吗？',
      success: res => {
        if (res.confirm) {
          db.collection('products').doc(id).remove({
            success: () => {
              wx.showToast({ title: '商品已删除', icon: 'success' });
              this.loadShelfProducts();
              this.loadDraftProducts();
            },
            fail: err => {
              wx.showToast({ title: '删除失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  // 下架商品为草稿
  downToDraft(e) {
    const id = e.currentTarget.dataset.id;
    const db = wx.cloud.database();

    db.collection('products').doc(id).update({
      data: {
        status: '草稿'
      },
      success: () => {
        wx.showToast({ title: '已下架到草稿', icon: 'success' });
        this.loadShelfProducts();
      },
      fail: err => {
        wx.showToast({ title: '操作失败', icon: 'none' });
      }
    });
  },

  // 上架商品
  publishProduct(e) {
    const id = e.currentTarget.dataset.id;
    const db = wx.cloud.database();

    db.collection('products').doc(id).update({
      data: {
        status: '已上架'
      },
      success: () => {
        wx.showToast({ title: '商品已上架', icon: 'success' });
        this.loadDraftProducts();
      },
      fail: err => {
        wx.showToast({ title: '操作失败', icon: 'none' });
      }
    });
  },

  // 跳转到编辑页面
  editProduct(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/productEdit/productEdit?id=${id}`
    });
  },

  // 生成二维码
  generateQRCode(e) {
    const productId = e.currentTarget.dataset.id;
    wx.cloud.callFunction({
      name: 'generateQRCode',
      data: { productId },
      success: res => {
        if (res.result.success) {
          wx.showToast({ title: '二维码生成成功', icon: 'success' });
          this.setData({ qrCodeBase64: res.result.qrCodeBase64 });
        } else {
          wx.showToast({ title: '生成失败，请重试', icon: 'none' });
        }
      },
      fail: err => {
        wx.showToast({ title: '调用失败，请检查网络', icon: 'none' });
      }
    });
  },

  // 关闭二维码显示区域
  closeQRCode() {
    this.setData({ qrCodeBase64: '' });
    wx.showToast({ title: '二维码已关闭', icon: 'success', duration: 1500 });
  },
  // 跳转到新增商品页面
addProduct() {
  wx.navigateTo({
    url: '/pages/productAdd/productAdd' // 确保路径与实际页面一致
  });
},

// 跳转到管理轮播图页面
navigateToCarouselManager() {
  wx.navigateTo({
    url: '/pages/carouselManager/carouselManager' // 确保路径与实际页面一致
  });
}
});