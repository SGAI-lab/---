import cloudConfig from '../../config/cloudConfig'; // 引入 cloudConfig 文件

Page({
  data: {
    isLoggedIn: false, // 是否已登录
    userInfo: {}, // 用户信息
    openid: '', // 用户唯一标识符
    isAdmin: false, // 是否为管理员
    isReviewMode: false, // 是否为审核模式
  },

  onLoad() {
    console.log("Member page loaded");
    this.checkEnvironment(); // 检查环境配置
  },

  // 检查当前环境配置
  checkEnvironment() {
    const db = wx.cloud.database();
    db.collection('settings')
      .doc('environment') // 假设环境配置的文档ID为 'environment'
      .get({
        success: res => {
          const mode = res.data.mode || 'production'; // 默认为生产模式
          console.log(`当前环境模式：${mode}`);
          if (mode === 'review') {
            this.setData({ isReviewMode: true });
            this.setOpenIDForReview(); // 设置审核模式的 openid
          } else {
            this.setData({ isReviewMode: false });
            this.checkLoginStatus(); // 正常登录流程
          }
        },
        fail: err => {
          console.error('获取环境配置失败：', err);
          wx.showToast({ title: '环境配置获取失败', icon: 'none' });
        }
      });
  },

  // 设置审核模式下的 openid
  setOpenIDForReview() {
    const reviewOpenID = 'test_openid_for_review'; // 预定义的审核 openid
    console.log('设置为审核模式，使用 openid:', reviewOpenID);

    const defaultAvatar = `cloud://${cloudConfig.env}.696d-${cloudConfig.env}-1331469944/icon/flower-fill.png`; // 动态默认头像路径

    // 设置假数据模拟登录
    this.setData({
      isLoggedIn: true,
      userInfo: {
        nickName: '审核用户',
        avatarUrl: defaultAvatar,
      },
      openid: reviewOpenID,
    });

    // 检查是否为管理员
    this.checkAdminStatus();
  },

  // 检查登录状态
  checkLoginStatus() {
    wx.getStorage({
      key: 'userInfo',
      success: res => {
        console.log("本地存储的用户信息：", res.data);
        this.setData({
          isLoggedIn: true,
          userInfo: res.data.userInfo, // 包含昵称和头像
          openid: res.data.openid,
        });

        // 在登录状态更新后检查管理员权限
        this.checkAdminStatus();
      },
      fail: err => {
        console.warn("本地存储不存在用户信息：", err);
        this.setData({
          isLoggedIn: false,
          userInfo: {},
          openid: '',
          isAdmin: false,
        });
      }
    });
  },

  // 检查管理员权限
  checkAdminStatus() {
    const db = wx.cloud.database();

    // 确保用户已登录
    if (!this.data.openid) {
      this.setData({ isAdmin: false });
      return;
    }

    db.collection('admins')
      .where({ openid: this.data.openid })
      .get({
        success: res => {
          if (res.data.length > 0) {
            this.setData({ isAdmin: true });
            console.log('用户是管理员');
          } else {
            this.setData({ isAdmin: false });
            console.log('用户不是管理员');
          }
        },
        fail: err => {
          console.error('查询管理员权限失败：', err);
          this.setData({ isAdmin: false });
        }
      });
  },

  // 登录并生成用户昵称和头像
  login() {
    const db = wx.cloud.database();

    // 调用云函数获取 openid
    wx.cloud.callFunction({
      name: 'login',
      success: cloudRes => {
        const openid = cloudRes.result.openid;

        // 检查用户是否已存在
        db.collection('users').doc(openid).get({
          success: userRes => {
            console.log('用户已存在，跳过创建：', userRes.data);

            // 更新页面状态
            this.setData({
              isLoggedIn: true,
              userInfo: { nickName: userRes.data.nickName, avatarUrl: userRes.data.avatarUrl },
              openid
            });

            // 本地存储用户信息
            wx.setStorage({
              key: 'userInfo',
              data: { userInfo: userRes.data, openid }
            });

            this.checkAdminStatus();
          },
          fail: err => {
            if (err.errCode === -1) {
              // 用户不存在，创建新记录
              const nickname = `用户${Math.floor(Math.random() * 10000)}`;
              const defaultAvatar = `cloud://${cloudConfig.env}.696d-${cloudConfig.env}-1331469944/icon/flower-fill.png`;

              db.collection('users').add({
                data: {
                  _id: openid, // 使用 openid 作为主键
                  nickName: nickname,
                  avatarUrl: defaultAvatar,
                  createdAt: new Date()
                },
                success: () => {
                  this.setData({
                    isLoggedIn: true,
                    userInfo: { nickName: nickname, avatarUrl: defaultAvatar },
                    openid
                  });

                  wx.setStorage({
                    key: 'userInfo',
                    data: { userInfo: { nickName: nickname, avatarUrl: defaultAvatar }, openid }
                  });

                  wx.showToast({ title: '登录成功', icon: 'success' });
                  this.checkAdminStatus();
                },
                fail: createErr => {
                  console.error('用户记录创建失败：', createErr);
                  wx.showToast({ title: '登录失败，请重试', icon: 'none' });
                }
              });
            } else {
              console.error('查询用户失败：', err);
              wx.showToast({ title: '登录失败，请重试', icon: 'none' });
            }
          }
        });
      },
      fail: err => {
        console.error('云函数调用失败：', err);
        wx.showToast({ title: '登录失败，请重试', icon: 'none' });
      }
    });
  },

  // 退出登录
  logout() {
    wx.removeStorage({
      key: 'userInfo',
      success: () => {
        console.log("用户信息已清除");
        this.setData({
          isLoggedIn: false,
          userInfo: {},
          openid: '',
          isAdmin: false
        });

        wx.showToast({ title: '已退出登录', icon: 'success' });
      },
      fail: err => {
        console.error("清除用户信息失败：", err);
        wx.showToast({ title: '退出失败，请重试', icon: 'none' });
      }
    });
  },

  // 跳转到后台管理页面
  navigateToManager() {
    if (!this.data.isAdmin) {
      wx.showToast({
        title: '您没有权限访问该页面',
        icon: 'none'
      });
      return;
    }

    wx.navigateTo({
      url: '/pages/productmanager/productmanager', // 跳转路径
      success: () => {
        console.log("成功跳转到后台管理页面");
      },
      fail: err => {
        console.error("跳转到后台管理页面失败：", err);
      }
    });
  }
});